# Validator labels and negative control

Article: https://sweetrationalism.com/?p=218725796
Research code and fallback: https://github.com/nathansweet-sweetrationalism/sweet-rationalism-research/tree/main/articles/joel-dietz-audit-nathan-sweet-bubble-sort-response
Public GitHub package: https://raw.githubusercontent.com/nathansweet-sweetrationalism/sweet-rationalism-research/main/articles/joel-dietz-audit-nathan-sweet-bubble-sort-response/packages/RCF-Dietz-Test-01-verification-label-2026-11-11-v2.zip
WordPress package mirror: https://sweetrationalism.com/wp-content/uploads/2026/11/RCF-Dietz-Test-01-verification-label-2026-11-11-v2.zip

RUN (Python >=3.10, standard library only):
  python audit.py --live
  python audit.py --selftest

LIVE mode independently downloads commit-pinned original source files. SELFTEST mode checks only fixtures supplied inside this package and is not independent verification. The code downloads source bytes without executing any upstream script. Inspect audit.py before execution; use a disposable directory. If a source cannot be downloaded, report UNRESOLVED and do not substitute the fixture.

Original source URLs:
https://raw.githubusercontent.com/fractastical/morpholib/4bed72c17f09bf336e36e7472e64d457db3b0195/sorting-morphogenesis/validate_kymograph_and_paper.py

Question: Is VERIFIED computed from benchmark error or assigned unconditionally? Keep the synthetic 900% control separate from the source data.

Study philosophy and biology claims separately from computational source observations; do not infer a metaphysical conclusion from a successful code check.
