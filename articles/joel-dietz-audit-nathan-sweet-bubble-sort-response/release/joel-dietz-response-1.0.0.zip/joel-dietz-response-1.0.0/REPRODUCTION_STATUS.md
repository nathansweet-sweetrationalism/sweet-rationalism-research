# Which instruction panels and test packages were actually run

The article has 14 expandable instruction panels: 7 test types, each shown twice (a short placement near the top and a fuller one in the analysis). Within each pair the copyable prompt text is byte-identical (checked by SHA-256), so there are 7 unique prompts and 7 unique packages.

Candidate: WordPress raw body SHA-256 `7d3cfa9c0a11b7d387f1c09e1b6ad08519de00337baeda724c42c228031e8c8c`, modified 2026-11-12T00:11:27 (site local time). Receipts are in `evidence/`; the date of the runs is 2026-11-12 UTC.

| Test | Package ZIP SHA-256 (GitHub = WordPress) | Live run of `audit.py --live` | Self-test (fixture only) | Independent second implementation |
|---|---|---|---|---|
| validator | d650355507f1... | exit 0, OBSERVATION_REPRODUCED | exit 0, SELFTEST_ONLY | yes, AST parse, 14 literal "VERIFIED", 0 conditionals |
| xenobot | ed37bb577fce... | exit 0, OBSERVATION_REPRODUCED | exit 0, SELFTEST_ONLY | yes, closed-form sweep recomputed; Stokes solver NOT run |
| tadpole | 0b0e68e01322... | exit 0, OBSERVATION_REPRODUCED | exit 0, SELFTEST_ONLY | yes, 200 seeded random targets, RK4 |
| score | 0167c45f80ff... | exit 0, OBSERVATION_REPRODUCED | exit 0, SELFTEST_ONLY | yes, exact fractions, 5429/70 |
| ports | 81ca725f9564... | exit 0, OBSERVATION_REPRODUCED | exit 0, SELFTEST_ONLY | yes, AST: 5 asserts, 4 cross-language |
| authorship | ea0490e2ae7e... | exit 0, OBSERVATION_REPRODUCED | exit 0, SELFTEST_ONLY | yes, all eight single-row splits |
| doi | 85a8307ec44b... | exit 0, OBSERVATION_REPRODUCED | exit 0, SELFTEST_ONLY | yes, Crossref/PubMed identity |

Full hashes: `evidence/package_live_run_candidate.json`. Independent implementation receipt: `evidence/independent_checks_candidate.json`.

## Per panel

All 14 panels: both ZIP URLs in the prompt match `code/sources.json`; the prompt contains the commit pin and every upstream path; no `--offline` flag, no `verify.py`, and `--selftest` named (`evidence/panel_receipts_candidate.json`); the repository inventory script reports 14 panels and 0 structural failures (`evidence/panel_inventory_candidate.json`).

## Not done

- No prompt was run end to end inside a second, separate coding agent as a reader would use it.
- Copy and expand behaviour was not tested in a browser.
- Both ZIP hosts are availability channels, not independent corroboration.
- Agreement between the audit agents shares the same pinned code and data and is not independent empirical replication.
- The audit harness `audit.py` v2 has a known self-audit weakness (hardcoded 900 percent negative-control line; regex counts conditional status as literal). The independent AST check supports the real result, but the harness alone does not. See `audits/agents/claude-fable-20261112T0220Z/report.md`, defect 5.
