# Release candidate 1.0.0: reconstruction and verification

Article: the WordPress article with post ID 218725796 (title in `metadata.json`), by Nathan Sweet. The WordPress article was published on 2026-11-12 on the owner's instruction (permalink in `metadata.json`). This archive holds the published raw body before any DOI links were added. It becomes the citable release when the Zenodo record is published.

The article is canonical on sweetrationalism.com. This archive preserves one frozen edition with its evidence. It has not been externally peer reviewed. Nothing in it implies that Zhang, Goldstein, Levin or Dietz have read, evaluated or endorsed it.

## What is here

| Path | Contents |
|---|---|
| `article/article.html` | The WordPress raw post body, byte for byte (SHA-256 in `metadata.json`) |
| `article/article.txt` | Readable UTF-8 rendering, with the 14 instruction panels shown as indented blocks |
| `article/bibliography.txt` | The article's reference section as text |
| `code/` | The audit harness `audit.py`, test inputs, the seven test packages (ZIP), submission validator, two editorial gate scripts, the release ledger and source manifest, as at the GitHub commit in `metadata.json` |
| `audits/` | Accepted independent audit evidence as merged into the repository, the coordinator's adjudication, and the DOI preparation note |
| `evidence/` | Receipts generated against this exact candidate (see `REPRODUCTION_STATUS.md`) and two proposed patches |
| `tools/` | The script that assembled this archive and the post-publication visibility check |
| `LIMITATIONS.md` | Unresolved issues, stated plainly |
| `SOURCE_PASSAGE_CHECKS.md`, `P061_ANALYSIS.md`, `VISIBILITY_AND_LINK_CHECKS.md`, `PROSE_AND_COHESION_REVIEW.md` | Reports of the full-text, statistics, visibility, link, prose and evidence-retention checks |
| `history/manifest.json` | Hashes and sizes of all 58 saved WordPress revisions and the current state; the bodies and diffs are in the separate `joel-dietz-response-history-1.0.0.zip` |
| `SHA256SUMS.txt` | SHA-256 of every other file |

Third-party papers and code are cited by DOI and URL and are not redistributed.

## Verify the archive (Python 3.10+, standard library)

```
unzip joel-dietz-response-1.0.0.zip
cd joel-dietz-response-1.0.0
python -c "import hashlib,pathlib,sys;bad=[l for l in pathlib.Path('SHA256SUMS.txt').read_text(encoding='utf-8').splitlines() if hashlib.sha256(pathlib.Path(l[66:]).read_bytes()).hexdigest()!=l[:64]];print('mismatches:',bad)"
```

Expected: `mismatches: []`. Then compare the SHA-256 of `article/article.html` with `wordpress.raw_body_sha256` in `metadata.json`.

## Re-run the source checks

Each package in `code/packages/` holds `audit.py`, a `test.json`, `README.md` and `PROMPT.md`. Read `audit.py` first. Then, inside an extracted package:

```
python audit.py --live        # downloads commit-pinned upstream files and checks them; needs network
python audit.py --selftest    # fixture-only parser check; NOT a check of any online source
```

`--live` downloads text and never runs upstream code. Exit code 2 and status `UNRESOLVED` mean a source could not be retrieved; no fixture is substituted.

## What the evidence does and does not show

See `REPRODUCTION_STATUS.md` (which of the 14 panels and 7 test packages were actually run, and how) and `LIMITATIONS.md`. In short: seven narrow source and code observations were reproduced from live pinned sources by independent implementations. That is a statement about code, saved data and arithmetic. It is not a replication of any biological experiment and says nothing about whether nonphysical causes exist.

## Computational disclosure for this archive

This archive was assembled in a Claude Code session running Claude Sonnet 5.5 (Anthropic) on 12 November 2026, following an earlier session of the same harness running Claude Fable 5.2 (Anthropic) that produced the merged audit evidence in `audits/agents/claude-fable-20261112T0220Z/`. The tools gathered and hashed sources, wrote and ran the checks, and assembled the files. The owner directed the work, personally completed the primary-source verification (author attestation, not independently reproduced), and decides what is released. The article's own computational disclosure appears in the article and was confirmed by the owner.
