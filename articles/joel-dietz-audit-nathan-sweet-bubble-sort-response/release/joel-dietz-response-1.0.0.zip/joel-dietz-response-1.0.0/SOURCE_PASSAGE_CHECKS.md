# Source-passage checks against full texts (2026-11-12)

Method: retrieve the open full text, extract text, search for the exact passage the article relies on. Hashes are in the project's literature index. Peer-review status is stated per source.

| # | What the article says | Source and version read | Result |
|---|---|---|---|
| 1 | Levin states "we did not add steps to the algorithm to check whether a swap had been completed, or to do specific things if an operation failed" | Levin (2026), *Philosophies* 11(5):161, open-access HTML page; page text SHA-256 `7a4ba9598b1d74ea4c36350483577568145da83f9c76b4d1799da579a3684f15` | CONFIRMED verbatim |
| 2 | The paper defines delayed gratification through actions that temporarily raise monotonicity error | Zhang, Goldstein, Levin, arXiv:2401.05375 (preprint of the *Adaptive Behavior* paper) | CONFIRMED: "actions that temporarily increase Monotonicity Error in order to achieve gains later on" |
| 3 | The draft's sentence about what the Zhang authors say on distinguishing strategic backtracking | same arXiv text | The first wording ("perturbations are needed") is not in the preprint. The preprint does say: "A random walker will sometimes move further from its goal and thus exhibit what may look like Delayed Gratification. To demonstrate DG as a problem-solving strategy it must be shown to be performed specifically in the context of barriers, not just part of a random strategy", and then compares Bubble and Insertion sort across numbers of frozen cells ("context-sensitive manner"). SUPPORTED IN SUBSTANCE; the draft sentence was reworded to follow that text. The journal version was not compared |
| 4 | Huh et al. propose convergence toward a shared statistical model of reality and discuss limitations and counterexamples | arXiv:2405.07987 (ICML 2024 paper) | CONFIRMED in the abstract |
| 5 | Jiang et al. study intra-model repetition and inter-model homogeneity, not awareness | arXiv:2510.22954 | CONFIRMED: both terms are defined in the abstract; no occurrence of conscious, phenomenal or self-aware |
| 6 | The Kriegman et al. mouth angle (65 versus 105 degrees) | Kriegman et al. (2021), *PNAS*, Europe PMC main text | UNRESOLVED. The main text describes a "C-shape" with "a single narrow mouth" and states no angle at all. Supplementary information was not retrieved |
| 7 | Quotes and attributions to Dietz's text | pinned upstream files and live Substack page (earlier audit stage) | CONFIRMED except two phrases fixed before the freeze |

Not checked against a passage: Anderson (1972), Beane et al. (2011), Pinet et al. (2019), Claverie and Wainwright (2014), Friedman et al. (2020), Kennedy et al. (2024), Balaguer (SEP), and Rabosky et al. (2018). For these only the DOI identity was verified. Crossref returned no retraction or correction notice for the ten DOIs in the reference list.

Item 3 was corrected in the draft on 2026-11-12. The preprint is the text checked; if the *Adaptive Behavior* version words this differently, the sentence should be compared against it.
