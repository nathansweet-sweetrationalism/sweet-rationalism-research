# The p = 0.061 comparison

Source: Dietz's signed outcome record (nanopublication) https://registry.knowledgepixels.com/np/RAJancwGOPEkHzBoZXGv_vu_snW0Lff2FktE85Me1P-fI and its pre-registration https://registry.knowledgepixels.com/np/RAilN4nbRHp3e3ZHqlbIgeL3UGPRV_KtQHtJD3gzVVdqw, fetched 2026-11-12. Digital signatures were not verified.

## What the record says
- Hypothesis H2 (primary): for target species within 50 Myr of a training species, the full 30-dimensional prediction has smaller absolute error than copying the nearest training relative. Test: one-sided paired Wilcoxon signed-rank on absolute error, n = 1,122; pre-registered alpha 0.01 for primary hypotheses.
- Result: median absolute error 0.038344 (full prediction) versus 0.039993 (nearest relative); ratio 0.95877; one-sided p = 0.060682. H2 is recorded as not supported.
- For comparison, H1 (full prediction versus consensus): ratio 0.4136, p = 1.05e-103, supported.

## Checks I ran
- The ratio recomputes from the two reported medians: 0.038344 / 0.039993 = 0.95877, a 4.12% reduction. Passed.
- Direction: the record's own test is "less", so the full prediction had the lower median error. Dietz's prose (article and companion) says copying the nearest relative "won by 4%". That reverses the direction in his own record. The draft had repeated his wording and has been corrected (below).
- The raw per-species errors WERE rerun later on 2026-11-12 (see the section below). The record's own p-value is still the one the draft cites, with the recomputation reported beside it.
- The fish "Thompson predictor" in his prose is the full 30-dimensional phylogenetic prediction. The 7-mode Thompson version is H6, which beats the consensus but has about 50% higher median error than the full prediction.

## Independent recomputation from raw inputs (2026-11-12)
Inputs, both hash-checked against the signed records: the locked predictions file `thompson_blind_predictions_registered.csv` (morpholib commit dac08493, sha256 1d50205f...) and FishShapes v1 specimens (Zenodo 6642650, sha256 7447fdc9...). Script: `evidence/recompute_h2.py`, output `evidence/recompute_h2.output.txt`; scipy 1.13.1, numpy 2.0.2. Calibration for BDmax/SL from the signed outcome record (observed = -0.0101 + 1.0183 x landmark ratio).

| Species ratio = | n (tau < 50) | full / nearest median error | H2 one-sided p | H1 p (vs consensus) |
|---|---|---|---|---|
| mean of specimen ratios | 1141 | 0.9569 | 0.0444 | 3.9e-107 |
| median of specimen ratios | 1141 | 0.9651 | 0.0570 | 2.1e-106 |
| ratio of species means | 1141 | 0.9687 | 0.0522 | 1.2e-106 |

Without the calibration the full prediction is still ahead of the nearest copy (ratio 0.971 to 0.975) but p is 0.18 to 0.21. Result: the direction of the record is reproduced (the full prediction has the LOWER median error), H1 reproduces to the same order of magnitude, and H2 is above the pre-registered alpha of 0.01 in every variant. NOT reproduced exactly: the record reports p = 0.0607 on n = 1122; mine is 0.044 to 0.057 on n = 1141. The 19-species difference and the averaging convention are undocumented in the signed record, and I did not use the author's code. Reading: H2 fails its pre-registered test whichever variant is used; the exact p-value is sensitive to unrecorded choices and sits near 0.05 in my versions.

## Reading
A one-sided p of 0.061 against alpha = 0.01 is not significant, so H2 failed on the pre-registered criterion. It is not evidence that the nearest relative did better. It also says nothing about P: a predictive win for a geometric model over a rival is a statement within D.

## Change made to the draft
Two sentences and the revision note now describe the comparison in the direction recorded, with the pre-registered alpha, and link the record. This corrects Dietz's wording that the draft had inherited, and it changes the draft's hash (see `metadata.json`).
