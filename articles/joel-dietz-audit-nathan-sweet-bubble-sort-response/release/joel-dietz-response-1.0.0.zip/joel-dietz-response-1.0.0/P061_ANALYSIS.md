# The p = 0.061 comparison

Source: Dietz's signed outcome record (nanopublication) https://registry.knowledgepixels.com/np/RAJancwGOPEkHzBoZXGv_vu_snW0Lff2FktE85Me1P-fI and its pre-registration https://registry.knowledgepixels.com/np/RAilN4nbRHp3e3ZHqlbIgeL3UGPRV_KtQHtJD3gzVVdqw, fetched 2026-11-12. Digital signatures were not verified.

## What the record says
- Hypothesis H2 (primary): for target species within 50 Myr of a training species, the full 30-dimensional prediction has smaller absolute error than copying the nearest training relative. Test: one-sided paired Wilcoxon signed-rank on absolute error, n = 1,122; pre-registered alpha 0.01 for primary hypotheses.
- Result: median absolute error 0.038344 (full prediction) versus 0.039993 (nearest relative); ratio 0.95877; one-sided p = 0.060682. H2 is recorded as not supported.
- For comparison, H1 (full prediction versus consensus): ratio 0.4136, p = 1.05e-103, supported.

## Checks I ran
- The ratio recomputes from the two reported medians: 0.038344 / 0.039993 = 0.95877, a 4.12% reduction. Passed.
- Direction: the record's own test is "less", so the full prediction had the lower median error. Dietz's prose (article and companion) says copying the nearest relative "won by 4%". That reverses the direction in his own record. The draft had repeated his wording and has been corrected (below).
- The raw per-species errors were not rerun, because that needs the FishShapes data and the author's pipeline. The p-value is taken from the record, not reproduced.
- The fish "Thompson predictor" in his prose is the full 30-dimensional phylogenetic prediction. The 7-mode Thompson version is H6, which beats the consensus but has about 50% higher median error than the full prediction.

## Reading
A one-sided p of 0.061 against alpha = 0.01 is not significant, so H2 failed on the pre-registered criterion. It is not evidence that the nearest relative did better. It also says nothing about P: a predictive win for a geometric model over a rival is a statement within D.

## Change made to the draft
Two sentences and the revision note now describe the comparison in the direction recorded, with the pre-registered alpha, and link the record. This corrects Dietz's wording that the draft had inherited, and it changes the draft's hash (see `metadata.json`).
