# Signed-out visibility, indexing and link checks

## Before publication (what can be checked now)
- The draft is not publicly reachable: `?p=218725796` returns 404 signed out, and it is absent from the public REST posts list and the post sitemap. Correct for a draft.
- Unlisting: the site's `unlist_posts` option holds 38 IDs and does not contain 218725796. After publication the article will therefore be listed and indexable. If the plan is to publish it hidden first, that has to be set before publishing.
- Yoast stored fields: no noindex or nofollow, canonical empty (a self-canonical is generated), schema article type Article, primary category Epistemology, SEO title, description, Open Graph and X fields set, hero image set with alt text. Yoast's stored scores (content 60, SEO title 28, meta description 22) are low; they may be stale until the post is re-saved in the editor.

## Baseline from a published sibling article
The same checks on the published Platonic-morphospace article give HTTP 200, an `index, follow` robots meta, self-canonical, Open Graph present, one JSON-LD graph (Article, WebPage, WebSite, Person and BreadcrumbList nodes), presence in the REST list and the sitemap, all four framework links, and three Zenodo DOI links (`evidence/signed_out_baseline_published_article.json`). It has two h1 elements (theme title plus a body h1), which the new article may share.

## After publication: result of the live check (2026-11-12)
The article was published and checked signed out (`evidence/signed_out_published_article.json`): HTTP 200, no redirect, no X-Robots-Tag, robots meta `index, follow`, self-canonical equal to the permalink, one JSON-LD graph with no parse errors, present in the public REST list and the post sitemap, all four framework links, one h1. The LiteSpeed page cache was purged and the live page serves the final text. No Zenodo DOI link is in the article yet.

## The script used

`tools/post_publish_checks.py <permalink>` repeats the baseline checks on the new URL. Expected: HTTP 200, `index, follow`, canonical equal to the permalink, JSON-LD without parse errors, listed in REST and the sitemap, four framework links, and the two Zenodo DOI links once added.

## Sitewide link matrix
All 38 published articles were scored by topical overlap and decided one by one (`evidence/link_matrix.csv`).
- Outbound: 9 are already linked from the draft. 4 are deferred (Levin Platonism background without Dietz or sorting content). 25 are rejected as a different interlocutor or question (mostly the Segall and consciousness series).
- Inbound plan, to apply only after publication: the bubble-sort article (direct sequel, one sentence), the "Religion with a pipette" article (source of the D-versus-D+P challenge), the xenobots article (Claim 7), and an entry in the Levin criticism index. No other article has a direct substantive connection. None of the 38 links to the draft now.
- Method limit: relevance was scored by keyword counts plus my reading of titles and excerpts, not a page-by-page human read.
