# Prose and cohesion review (machine measurement plus one read)

This is a review for the owner to act on, not a rewrite. The article was read once end to end in this session and measured with the repository's heuristic prose audit and my own counts. It was not read aloud or by text-to-speech, and the owner has read it several times.

## Measurements (authorial prose, instruction panels excluded)
- 95 paragraphs, 415 sentences, mean 15.5 words per sentence, none over 55 words. No em dashes. No stock phrases from the project's tic list.
- 30 question marks. 23 sentences start with "If". Direct address to Dietz ("Joel," or "your") appears about 9 times against third person elsewhere.
- The repository audit's near-duplicate paragraph flags are all the instruction-panel summary lines, not authorial prose. Its other flags (three-part lists, repeated openings, reverse contrasts) sit mostly inside the panel text and the procedural prompt.

## What I would look at
1. The same conclusion appears in at least six places: the deck, the Bottom line, the "crucial result" section, the closing sections and the test paragraph (zero earned support; the 77.6% is not a probability; sufficiency of D does not refute P). Each has a different job, but the third and fourth restatements could be shortened without losing a premise.
2. The "If he means X ... if he means Y" device is used about a dozen times. It is fair-minded but monotone in the middle sections.
3. The person switches to "Joel, ..." and "your validator" in the "audit the auditor" section while the rest says "Joel says". If deliberate, fine; otherwise unify.
4. The satire ("a rubber stamp that learned Python") is intact and should stay.

Point 1 was addressed at the owner's request on 2026-11-12 by rewording rather than cutting: the opening deck (the headline average), the opening paragraph (a rebuttal whose numbers sit on the author's side), the closing-section paragraph on where Dietz ends, the "what do the tests license" paragraph and the final paragraph (a label cannot win a disagreement) now each make a distinct point. The Bottom line, the formal section and the subtraction test paragraph were left as they were. No source, number or claim was removed. Point 2 (the "if he means X, if he means Y" device) and point 3 (the switch to "Joel," address) were also addressed later on 2026-11-12: six of the paired if-sentences were recast as "read as / as a" constructions and all second-person address to Dietz was moved to third person (18 if-sentences remain, most of them single conditionals). Point 4 is unchanged.

## Evidence-retention check against all 58 saved revisions
Run with `scripts/evidence_retention_audit.py`, each revision as the original and the candidate as the new text (`evidence/evidence_retention_all_revisions.json`). Finding: three DOIs that appear in earlier revisions are absent now. They are the corrected targets for two further wrong DOIs in Dietz's materials that earlier drafts reported. Vandenberg et al. 2012: the printed DOI 10.1016/j.ydbio.2012.01.027 resolves to an integrin paper, and the correct one is 10.1002/dvdy.23770. Pietak and Levin 2016: the printed 10.3389/fphys.2016.00178 resolves to a Kv1.3 mitochondria paper, and the correct one is 10.3389/fbioe.2016.00055. I confirmed both mismatches against Crossref and the pinned companion. The article had kept three. At the owner's instruction both were restored on 2026-11-12 with correct references (the third dropped DOI, Pezzulo and Levin 2015, checks out and was correctly removed).

## Later change: Bottom line, deck and typed-in section (2026-11-12)
At the owner's request the Bottom line was rewritten to list the main discrepancies compactly (721 characters), the opening deck was cut to its headline and question, and a short section was added that defines typed-in and stipulated results with a four-row table (validator label, 77.6% display string, 65-degree stipulated peak, supplied tadpole target) and notes that the first version of the test script has the same kind of fixed line. No source or number changed.

An image note was added under the Bottom line (2026-11-12): the hero illustration is satire; the stamp is the validator's constant label; the 900% sheet is the author's synthetic control; the 0% panel is Dietz's score, not stamped by his validator; and the article does not claim Michael Levin wrote the validator or endorsed the audit. The image itself was not changed.
