# Unresolved issues at freeze

Carried from the coordinator's adjudication (`audits/AGENT_ADJUDICATION_2026-11-12.md`) and the audits in this archive, with the status found when freezing. Nothing is silently closed.

## What was done since the first freeze (2026-11-12)
Full-text passage checks (`SOURCE_PASSAGE_CHECKS.md`), the p = 0.061 analysis (`P061_ANALYSIS.md`), the sitewide link matrix and visibility checks (`VISIBILITY_AND_LINK_CHECKS.md`), a prose and cohesion review plus an evidence-retention run over all 58 saved revisions (`PROSE_AND_COHESION_REVIEW.md`), and the revision-history reconstruction (`history/`, shipped as a separate ZIP). On the owner's request the draft gained a Computational disclosure section, dated Revision notes and an original-code link, and two rounds of correction: the direction of the nearest-relative fish comparison, and the restoration of two verified wrong DOIs together with a reworded sentence about the Zhang et al. preprint.

## Still open
1. The sentence about what the Zhang et al. authors say on random walkers and barriers was reworded to the arXiv preprint's text. The journal version was not compared.
2. The p = 0.061 value is taken from Dietz's signed record, not reproduced from the raw FishShapes data; nanopublication signatures were not verified.
3. Xenobot 65 versus 105 degrees remains unresolved. The Kriegman et al. main text states no angle; its supplement and the upstream Stokes solver were not examined.
4. Passage-level checks were not done for Anderson (1972), Beane et al. (2011), Pinet et al. (2019), Claverie and Wainwright (2014), Friedman et al. (2020), Kennedy et al. (2024), Balaguer (SEP) and Rabosky et al. (2018). Only DOI identity was checked for those.
5. Formal duties: no proof assistant or SMT solver was used; the 17 inventoried numerical statements reproduce by exact arithmetic or bounded tests.
6. Prose: reviewed by measurement and one read, not by ear. The repeated restatements of the conclusion were reworded into distinct points (2026-11-12); the repeated if-then device and the switch to second-person address were reworded later the same day.
7. Five wrong DOIs in Dietz's materials are now stated in the article (the three covered by the executable test, plus Pietak and Levin 2016 and Vandenberg et al. 2012, each a single lookup). Both additions were verified against Crossref and PubMed and are in the reference list.
8. The signed-out indexing, canonical, sitemap and structured-data checks passed on the live article (2026-11-12). Inbound links from other articles have not been added yet. The article does not yet link its Zenodo DOIs; that is a post-publication step.
9. The agents' agreement shares the same pinned code and data and is not independent empirical replication.

## Candidate facts the owner should know
- The original code repository (`Zhangtaining/cell_research`) carries no licence file on GitHub, was last pushed 2024-10-30, and the earlier audit ran its commit `1fd2bd5`.
- The article body cites the earlier audit by its concept DOI 10.5281/zenodo.23866304; the Zenodo record references the version DOI 10.5281/zenodo.23866847. Both resolve to the same work.
- The history ZIP publishes all 58 saved revisions plus the current state, including earlier wording the author later changed.

## Tooling issues found
- `scripts/bottom_line_gate.py` rejects every article with an italic opening deck because its regular expression is over-escaped. The candidate fails the original gate and passes with the one-line fix (`evidence/bottom_line_gate_candidate.*`, `evidence/proposed_patch_bottom_line_gate.patch`). The fix is in an open pull request, not merged.
- `scripts/prose_audit.py --json` crashes on Windows unless run in UTF-8 mode.
- The audit harness v2 has a known self-audit weakness (hardcoded 900 percent negative-control line; a regular expression that counts a conditional status as literal). See `audits/agents/claude-fable-20261112T0220Z/report.md`, defect 5.

## Scope reminders
Agreement among AI audits is not independent replication. A source-code or arithmetic check does not establish or refute any biological or metaphysical claim. The reserved DOI is not registered until Zenodo publication.
