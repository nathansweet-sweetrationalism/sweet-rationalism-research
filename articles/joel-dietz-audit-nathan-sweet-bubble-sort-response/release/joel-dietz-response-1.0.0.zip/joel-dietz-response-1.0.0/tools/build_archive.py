#!/usr/bin/env python3
"""Assemble the frozen release-candidate archive for the Dietz-response article.
Stdlib only. Usage: python build_archive.py <wp_raw.json> <repo_dir> <out_dir>
The article body is taken byte-for-byte from the WordPress readback.
"""
import hashlib, html, json, pathlib, re, shutil, subprocess, sys, zipfile

wp, repo, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3])
A = "articles/joel-dietz-audit-nathan-sweet-bubble-sort-response"
VERSION, ROOT = "1.0.0", "joel-dietz-response-1.0.0"
RESERVED = "10.5281/zenodo.24151128"
sha = lambda b: hashlib.sha256(b).hexdigest()
git = lambda *a: subprocess.run(["git", "-C", str(repo), *a], capture_output=True, text=True, encoding="utf-8").stdout.strip()

d = json.loads(wp.read_text(encoding="utf-8")); content = d["content"]
root = out / ROOT
if root.exists(): shutil.rmtree(root)
for sub in ("article", "code", "audits", "evidence", "tools"): (root / sub).mkdir(parents=True)

# 1. article: exact HTML, readable UTF-8 text with panel prompts shown as indented blocks
(root / "article/article.html").write_bytes(content.encode("utf-8"))
def render(c):
    def panel(m):
        ta = re.search(r"<textarea\b[^>]*>([\s\S]*?)</textarea>", m.group(0))
        pid = re.search(r'id="([^"]+)"', m.group(0)).group(1)
        body = "\n".join("    " + l for l in html.unescape(ta.group(1)).splitlines())
        return f"\n[INSTRUCTION PANEL {pid}]\n{body}\n[END PANEL]\n"
    t = re.sub(r"<details\b[\s\S]*?</details>", panel, c)
    t = re.sub(r"<!--.*?-->", "", t, flags=re.S)
    t = re.sub(r"<a\b[^>]*href=\"([^\"]+)\"[^>]*>([\s\S]*?)</a>", lambda m: f"{m.group(2)} <{m.group(1)}>", t)
    t = re.sub(r"<h(\d)[^>]*>", lambda m: "\n" + "#" * int(m.group(1)) + " ", t)
    t = re.sub(r"</(p|h\d|li|tr|div|blockquote|figcaption|pre|summary)>", "\n", t)
    t = re.sub(r"<[^>]+>", "", t)
    return re.sub(r"\n[ \t]*\n+", "\n\n", html.unescape(t)).strip() + "\n"
(root / "article/article.txt").write_text(render(content), encoding="utf-8", newline="\n")
refs = content[content.find(">References<"):]
(root / "article/bibliography.txt").write_text(render(refs), encoding="utf-8", newline="\n")

# 2. code and packages, copied from the repository at HEAD
for rel in ("audit.py", "sources.json", "README.md", "test-data", "packages", "agents", "release_status.json"):
    s = repo / A / rel
    (shutil.copytree if s.is_dir() else shutil.copy2)(s, root / "code" / rel)
for g in ("bottom_line_gate.py", "core_framework_links_gate.py"):
    shutil.copy2(repo / "scripts" / g, root / "code" / g)

# 3. accepted audit evidence, as merged on main
shutil.copytree(repo / A / "audits", root / "audits", dirs_exist_ok=True)
shutil.copytree(repo / A / "doi", root / "audits/doi_preparation", dirs_exist_ok=True)

# 4. tools used to build this archive
shutil.copy2(pathlib.Path(__file__), root / "tools/build_archive.py")
(root / "history").mkdir(exist_ok=True)
shutil.copy2(wp.parent / "history/manifest.json", root / "history/manifest.json")

# 5. evidence receipts passed in as extra files
for extra in sys.argv[4:]:
    shutil.copy2(extra, root / "evidence" / pathlib.Path(extra).name)

meta = {
    "title": d["title"], "author": "Nathan Sweet", "version": VERSION,
    "wordpress": {"post_id": d["id"], "status_at_freeze": d["status"], "modified_local": d["modified"],
                  "raw_body_sha256": sha(content.encode("utf-8")), "raw_body_utf16_units": len(content.encode("utf-16-le")) // 2,
                  "slug": d["slug"], "final_permalink": d["link"], "published_local": d["date"], "note": "Published on the owner's instruction 2026-11-12; the body in this archive is the published raw body before any DOI links were added."},
    "zenodo": {"draft_record_id": "24151128", "reserved_doi": RESERVED, "state": "RESERVED_NOT_REGISTERED",
               "concept_doi": None, "version_doi": None},
    "github": {"repository": "nathansweet-sweetrationalism/sweet-rationalism-research", "article_directory": A,
               "commit_at_freeze": git("rev-parse", "HEAD"), "upstream_pin": "fractastical/morpholib@4bed72c17f09bf336e36e7472e64d457db3b0195"},
    "original_research": {"paper_doi": "10.1177/10597123241269740", "code": "https://github.com/Zhangtaining/cell_research",
                          "code_commit_used_by_prior_audit": "1fd2bd5921c1f6b423a71f691d5189106a8a1020",
                          "note": "Cited, not redistributed. No claim of endorsement or evaluation by the original authors."},
    "license_proposed": "CC-BY-4.0 (matches the author's other Zenodo records; owner to confirm)",
    "peer_review": "None. Independent article.",
}
(root / "metadata.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
print("files before manifest:", sum(1 for p in root.rglob("*") if p.is_file()))
