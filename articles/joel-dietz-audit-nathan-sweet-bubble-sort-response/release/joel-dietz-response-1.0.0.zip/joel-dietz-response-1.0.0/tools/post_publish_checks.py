#!/usr/bin/env python3
"""Signed-out visibility checks for one WordPress article URL. Stdlib only.
Usage: python post_publish_checks.py <permalink> [--expect-index|--expect-noindex] > receipt.json
Checks status, redirects, X-Robots-Tag, meta robots, canonical, Open Graph, JSON-LD (Yoast graph),
inclusion in the public REST posts list and the post sitemap, the four framework links, and DOI links.
"""
import html, json, re, sys, urllib.request, urllib.error, urllib.parse
UA = {"User-Agent": "Mozilla/5.0 (signed-out visibility check)"}
url = sys.argv[1]; want_index = "--expect-noindex" not in sys.argv
def get(u, **kw):
    req = urllib.request.Request(u, headers=UA)
    try:
        r = urllib.request.urlopen(req, timeout=60); return r.status, r.read().decode("utf-8", "replace"), dict(r.headers), r.geturl()
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace"), dict(e.headers), u
st, body, hd, final = get(url)
meta = lambda n, a="name": (re.search(r"<meta[^>]+%s=['\"]%s['\"][^>]+content=['\"]([^'\"]*)['\"]" % (a, re.escape(n)), body) or [None, None])[1]
canon = (re.search(r'<link[^>]+rel="canonical"[^>]+href="([^"]+)"', body) or [None, None])[1]
robots = meta("robots"); xrobots = hd.get("X-Robots-Tag") or hd.get("x-robots-tag")
ld = []
for m in re.finditer(r'<script type="application/ld\+json"[^>]*>([\s\S]*?)</script>', body):
    try: ld.append(json.loads(m.group(1)))
    except Exception as e: ld.append({"parse_error": str(e)})
types = sorted({(n.get("@type") if isinstance(n.get("@type"), str) else "/".join(n.get("@type", []))) for g in ld for n in (g.get("@graph", [g]) if isinstance(g, dict) else [])})
slug_path = urllib.parse.urlparse(url).path.rstrip("/")
rest = json.loads(get("https://sweetrationalism.com/wp-json/wp/v2/posts?per_page=100&_fields=link")[1])
sm = re.findall(r"<loc>([^<]+)</loc>", get("https://sweetrationalism.com/post-sitemap.xml")[1])
fw = ["recursive-corrigibility-framework", "ontology-scale-relative-realism", "interoperability-framework-bridge", "sweet-rationalism-a-foundational-framework"]
res = {
    "url": url, "http": st, "redirected_to": None if final.rstrip("/") == url.rstrip("/") else final,
    "x_robots_tag": xrobots, "meta_robots": robots, "canonical": canon, "canonical_equals_url": (canon or "").rstrip("/") == url.rstrip("/"),
    "og_title": meta("og:title", "property"), "og_image": meta("og:image", "property"), "og_url": meta("og:url", "property"),
    "jsonld_blocks": len(ld), "jsonld_types": types, "jsonld_parse_errors": sum(1 for g in ld if isinstance(g, dict) and "parse_error" in g),
    "in_public_rest_list": any(p["link"].rstrip("/") == url.rstrip("/") for p in rest),
    "in_post_sitemap": any(u.rstrip("/") == url.rstrip("/") for u in sm),
    "framework_links_present": {k: ("/frameworks/" + k) in body for k in fw},
    "doi_links_present": sorted(set(re.findall(r"https://doi\.org/10\.5281/zenodo\.\d+", body))),
    "h1_count": len(re.findall(r"<h1\b", body)), "title_tag": (re.search(r"<title>([^<]*)</title>", body) or [None, None])[1],
}
idx_ok = ("noindex" not in (robots or "").lower()) and ("noindex" not in (xrobots or "").lower())
res["expectation"] = "index" if want_index else "noindex"
res["indexability_matches_expectation"] = (idx_ok == want_index)
res["all_four_framework_links"] = all(res["framework_links_present"].values())
print(json.dumps(res, indent=1, ensure_ascii=False))
