#!/usr/bin/env python3
"""Rebuild the release candidate (main archive, history ZIP, audit TXT) from the current wp_raw.json,
docs/, ev/ and history/. Stdlib only. Run from the dietz-doi directory:
  python rebuild_release.py <frozen_repo_dir> <out_dir_outside_onedrive>
Appends the current post state to history/ if it differs from the last history entry.
"""
import difflib, hashlib, json, pathlib, shutil, subprocess, sys, zipfile

here = pathlib.Path('.'); frozen = pathlib.Path(sys.argv[1]); base = pathlib.Path(sys.argv[2])
NAME, HNAME = 'joel-dietz-response-1.0.0', 'joel-dietz-response-history-1.0.0'
d = json.load(open('wp_raw.json', encoding='utf-8')); c = d['content']
H = here / 'history'; m = json.load(open(H / 'manifest.json'))
cur = hashlib.sha256(c.encode()).hexdigest()
if m['revisions'][-1]['sha256'] != cur:
    seq = len(m['revisions']) + 1
    fn = 'revisions/%02d_postexport_state_%s.html' % (seq, d['modified'].replace(':', '').replace('-', '').replace(' ', 'T'))
    (H / fn).write_bytes(c.encode('utf-8'))
    prev = (H / m['revisions'][-1]['file']).read_bytes().decode('utf-8')
    df = list(difflib.unified_diff(prev.splitlines(), c.splitlines(), 'previous', 'state%d' % seq, lineterm='', n=0))
    dn = 'diffs/%02d_to_%02d_postexport.diff' % (seq - 1, seq); (H / dn).write_text('\n'.join(df) + '\n', encoding='utf-8', newline='\n')
    m['revisions'].append({'seq': seq, 'revision_id': None, 'modified_gmt': '(post-export state, site time %s)' % d['modified'], 'author_id': 4, 'file': fn, 'sha256': cur, 'bytes': len(c.encode()), 'diff_from_previous': dn,
        'lines_added': sum(1 for l in df if l.startswith('+') and not l.startswith('+++')), 'lines_removed': sum(1 for l in df if l.startswith('-') and not l.startswith('---')), 'note': 'Saved after the revision export.'})
    m['revision_count'] = len(m['revisions']); m['current_post_sha256'] = cur
    json.dump(m, open(H / 'manifest.json', 'w', encoding='utf-8'), indent=1)
if base.exists(): shutil.rmtree(base, ignore_errors=True)
base.mkdir(parents=True)
ev = sorted(str(p) for p in (here / 'ev').iterdir() if p.is_file())
subprocess.run([sys.executable, '-I', '-X', 'utf8', 'build_archive.py', 'wp_raw.json', str(frozen), str(base)] + ev, check=True)
R = base / NAME
for p in (here / 'docs').glob('*.md'): shutil.copy2(p, R / p.name)
shutil.copy2('build_archive.py', R / 'tools/build_archive.py'); shutil.copy2('post_publish_checks.py', R / 'tools/post_publish_checks.py'); shutil.copy2('rebuild_release.py', R / 'tools/rebuild_release.py')
readme = '# Revision history reconstruction, WordPress post 218725796\n\nAll 58 saved revisions (IDs 218725797 to 218725897, 2026-11-11 08:04 to 2026-11-12 04:14 GMT) were exported from the authenticated WordPress post on 2026-11-12; none was unavailable. Later entries are post states saved after the export. `revisions/` holds each exact body; `diffs/` holds line diffs between neighbours; `manifest.json` has hashes and sizes; `SHA256SUMS.txt` covers every other file. Earlier wording is preserved here for provenance and is not current endorsement.\n'
items = {p.relative_to(H).as_posix(): p.read_bytes() for p in H.rglob('*') if p.is_file()}; items['README.md'] = readme.encode()
sums = ''.join('%s  %s\n' % (hashlib.sha256(b).hexdigest(), n) for n, b in sorted(items.items()))
hz = base / (HNAME + '.zip')
def zadd(z, top, n, b):
    zi = zipfile.ZipInfo(top + '/' + n, (2026, 11, 12, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, b)
with zipfile.ZipFile(hz, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for n, b in sorted(items.items()): zadd(z, HNAME, n, b)
    zadd(z, HNAME, 'SHA256SUMS.txt', sums.encode())
hh = hashlib.sha256(hz.read_bytes()).hexdigest()
order = ['README_RECONSTRUCTION.md', 'REPRODUCTION_STATUS.md', 'SOURCE_PASSAGE_CHECKS.md', 'P061_ANALYSIS.md', 'VISIBILITY_AND_LINK_CHECKS.md', 'PROSE_AND_COHESION_REVIEW.md', 'LIMITATIONS.md']
adir = R / 'audit'; adir.mkdir(exist_ok=True)
(adir / (NAME.replace('-1.0.0', '') + '-audit-1.0.0.txt')).write_text('\n\n---\n\n'.join((R / f).read_text(encoding='utf-8') for f in order), encoding='utf-8', newline='\n')
meta = json.load(open(R / 'metadata.json', encoding='utf-8')); meta['history_zip'] = {'file': HNAME + '.zip', 'sha256': hh, 'revisions': 58, 'states_after_export': len(m['revisions']) - 58}
(R / 'metadata.json').write_text(json.dumps(meta, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
files = sorted(p for p in R.rglob('*') if p.is_file() and p.name != 'SHA256SUMS.txt'); s = R / 'SHA256SUMS.txt'
s.write_text(''.join('%s  %s\n' % (hashlib.sha256(p.read_bytes()).hexdigest(), p.relative_to(R).as_posix()) for p in files), encoding='utf-8', newline='\n')
zp = base / (NAME + '.zip')
with zipfile.ZipFile(zp, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted(files + [s]): zadd(z, NAME, p.relative_to(R).as_posix(), p.read_bytes())
def verify(z_, top):
    ex = base / ('_v_' + z_.stem);
    with zipfile.ZipFile(z_) as z: b0 = z.testzip(); z.extractall(ex)
    V = ex / top; ls = (V / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines()
    bad = [l[66:] for l in ls if hashlib.sha256((V / l[66:]).read_bytes()).hexdigest() != l[:64]]
    extra = sorted({p.relative_to(V).as_posix() for p in V.rglob('*') if p.is_file()} - {l[66:] for l in ls} - {'SHA256SUMS.txt'})
    return b0, len(ls), bad, extra, V
r = verify(zp, NAME); art = hashlib.sha256((r[4] / 'article/article.html').read_bytes()).hexdigest(); mm = json.load(open(r[4] / 'metadata.json', encoding='utf-8'))
print('MAIN', r[:4], 'article==metadata', art == mm['wordpress']['raw_body_sha256'], art[:16], mm['wordpress']['modified_local'], 'history hash linked', mm['history_zip']['sha256'] == hh)
print('HISTORY', verify(hz, HNAME)[:4])
dest = here / 'release'; dest.mkdir(exist_ok=True)
aud = next(adir.glob('*.txt'))
for f in (zp, hz, aud): shutil.copy2(f, dest / f.name)
(dest / 'ZIP_SHA256.txt').write_text(''.join('%s  %s\n' % (hashlib.sha256((dest / f.name).read_bytes()).hexdigest(), f.name) for f in (zp, hz, aud)), encoding='utf-8', newline='\n')
print((dest / 'ZIP_SHA256.txt').read_text()); print('sizes', zp.stat().st_size, hz.stat().st_size, 'history states', len(m['revisions']))
