"""Independent recomputation of the pre-registered H1/H2 comparisons from raw inputs.
Inputs (both hash-checked against the signed records):
  blind_pred.csv   = thompson_blind_predictions_registered.csv @ morpholib dac08493 (sha256 1d50205f...)
  fishshapes.csv   = FishShapes v1 specimens, Zenodo 6642650 (sha256 7447fdc9...)
Calibration for BDmax/SL from the signed outcome record: observed = -0.0101 + 1.0183 * landmark_ratio.
Written for this audit; does not use the author's code.
"""
import csv, hashlib, statistics, sys
from collections import defaultdict
import numpy as np
from scipy import stats

def sha(p): return hashlib.sha256(open(p, 'rb').read()).hexdigest()
assert sha('blind_pred.csv') == '1d50205ffc2ed9954e707eba2e3db6aaa4871620df6cecf9e4cf766fe3046171'
assert sha('fishshapes.csv') == '7447fdc92c5fd5c9ecf1d9713bbd4207d2de7ab4b2ea0e320871041da8e34264'

pred = list(csv.DictReader(open('blind_pred.csv', encoding='utf-8')))
spec = defaultdict(list)
for r in csv.DictReader(open('fishshapes.csv', encoding='utf-8')):
    try:
        sl, bd = float(r['Standard_length']), float(r['Max_body_depth'])
    except ValueError:
        continue
    if sl > 0 and bd > 0:
        spec[r['Tree_name']].append((bd, sl))

def observed(sp, how):
    v = spec[sp]
    if how == 'mean_of_ratios': return float(np.mean([b / s for b, s in v]))
    if how == 'median_of_ratios': return float(np.median([b / s for b, s in v]))
    if how == 'ratio_of_means': return float(np.mean([b for b, s in v]) / np.mean([s for b, s in v]))

A, B = -0.0101, 1.0183
print('targets in prediction file:', len(pred), '| species in FishShapes:', len(spec))
for how in ('mean_of_ratios', 'median_of_ratios', 'ratio_of_means'):
    for calib in (True, False):
        rows = [r for r in pred if float(r['tau_myr']) < 50 and r['species'] in spec]
        f = lambda x: (A + B * x) if calib else x
        obs = np.array([observed(r['species'], how) for r in rows])
        e = {m: np.abs(f(np.array([float(r[m + '_BDmax_over_SL']) for r in rows])) - obs) for m in ('full30', 'consensus', 'nearest', 'thompson7')}
        med = {m: float(np.median(v)) for m, v in e.items()}
        h2 = stats.wilcoxon(e['full30'], e['nearest'], alternative='less')
        h2two = stats.wilcoxon(e['full30'], e['nearest'])
        h1 = stats.wilcoxon(e['full30'], e['consensus'], alternative='less')
        print(f"\n[{how} | calibration {'on' if calib else 'off'}] tau<50, n={len(rows)}")
        print('  medians', {k: round(v, 6) for k, v in med.items()})
        print('  full30/nearest ratio', round(med['full30'] / med['nearest'], 5), '| full30/consensus', round(med['full30'] / med['consensus'], 5))
        print('  H2 one-sided p (full30 < nearest):', h2.pvalue, '| two-sided:', h2two.pvalue)
        print('  H1 one-sided p (full30 < consensus):', h1.pvalue)
        print('  share of species where full30 error < nearest error:', round(float(np.mean(e['full30'] < e['nearest'])), 4))
